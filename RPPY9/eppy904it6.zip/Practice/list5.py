list1= ['a', 'b', 'c']
print("附加之前:", list1)
print("附加之前長度 = ", len(list1))
list1.append(["def","ghij"])
print("附加之後:", list1)
print("附加之後長度 = ", len(list1))
print(list1[3])