a = [5, 2, 1, 9, 6]
#sorted方式排序後輸出
print(a)
#sorted方式由大而小排序後輸出
print(a)
#sort方式由大而小排序後輸出
print(a)