list1=['H','i']
tuple1=('H','i')
print(tuple1)
print(list1)
tuple1[1]='a'
list1[1]='a'
print(tuple1)
print(list1)