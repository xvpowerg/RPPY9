list1=['H','e','l','l','o', 'W','o','r','l','d']
print(list1[0])
print(list1[1])
print(list1[-1])
print(list1[-3])