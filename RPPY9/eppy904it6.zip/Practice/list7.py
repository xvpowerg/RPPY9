list1 = ['this', 'is', 'list']
print(list1)
#請新增資料
print(list1)
#請新增資料
print(list1)
