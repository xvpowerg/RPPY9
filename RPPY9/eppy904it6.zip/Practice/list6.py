list1= ['a', 'b', 'c']
print("擴展之前:", list1)
print("擴展之前長度 = ", len(list1))
#請擴展資料
print("擴展之後:", list1)
print("擴展之後長度 = ", len(list1))
print(list1[3])
