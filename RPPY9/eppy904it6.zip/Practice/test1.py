x=y=[0,1,2]
print(x,y)
print(id(x))
print(id(y))
x=x+[89,99]
print(x,y)
print(id(x))
print(id(y))
print(x is y)
