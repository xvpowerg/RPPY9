a= input(print("這是測試"))
b= input("請輸入")
if len(b) == 1:
  print("一個字")
else:
  print("多個字")
