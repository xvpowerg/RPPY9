a=b=[0,1,2]
print(a,b)
print(id(a))
print(id(b))
a+=[89,99]
print(a,b)
print(id(a))
print(id(b))
print(a is b)
