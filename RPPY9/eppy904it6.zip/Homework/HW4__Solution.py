
# coding: utf-8

# ![image.png](attachment:image.png)

# In[1]:


# fruits 是資料型態為 list 的變數，初始化時，存有五種水果名稱的字串，因此這個 list 內有五個字串元素
fruits = ["香蕉","蘋果","橘子","鳳梨","西瓜"]
# while 迴圈，當條件判斷式是為真（True），就會執行以下的程式區塊
# 在這裡就是預設為無窮迴圈，因為條件判斷式永遠等於 True
while True:
    # 透過 input() 函數，列印字串內容，並等待使用者輸入字串，儲存到 fruit 變數內
    fruit = input("請輸入喜歡的水果(Enter 結束)：")
    # 如果（if）fruit字串變數等於空字串（代表使用者直接按下Enter鍵，並沒有輸入任何文字），就執行以下區塊
    if (fruit==""):
        # break 代表直接跳出迴圈，適用於 while、for 迴圈
        break
    # n 是數值變數，fruits.count，這個 list 的 count 函數可以搜尋 list 內有幾個 fruit 字串變數內容
    n = fruits.count(fruit) 
    # 如果 n 數值變數大於 0 ，代表有找到 fruit 字串變數的內容，這也代表輸入的水果名稱存在於 list 中
    if (n>0):  # 串列元素存在
        # p 變數會記錄索引值，透過 list 的 index 函數可以回傳 fruit 字串內容在第幾個索引
        p=fruits.index(fruit)
        # print 函數會列印字串內容
        # p+1 是因為索引值是由 0 開始算，加 1 之後，就會變成項次
        print(fruit+"在串列中的第"+str(p+1 )+"項")
    # 如果 n 小於等於 0 的狀況，就會執行以下區塊
    else:
        # 列印字串訊息，並告訴使用者，該 fruit 字串不在 list 中
        print(fruit,"不在串列中!")

