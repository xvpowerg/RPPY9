var1=20
#請輸出var1類型
var2=123.45
#請輸出var2類型
var3=True
#請輸出var3類型
var4='string1'
#請輸出var4類型
