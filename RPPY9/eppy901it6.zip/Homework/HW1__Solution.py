myname="巨匠電腦"
myclass="Python AI 入門"
print(myname+"你好!，我現在上的課程是:"+myclass)
print("我心情很好，所以等一下要說三次")
print("這課程讓我很開心，我會努力的!"*3)
