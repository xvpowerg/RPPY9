import re
inputStr = "hello 123 world 456"
replacedStr = re.sub(" ", " ", inputStr) #請填寫規則
print(replacedStr)
