import re
text = 'one, two...ten'
re1=re.split('', text)#請填寫規則
print(re1)
re1=re.split('', text, maxsplit=1)#請填寫規則
print(re1)
