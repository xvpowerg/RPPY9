import numpy as np
a = np.arange(12).reshape(3,4)
print(a)
#請加入語法
print("-------------------")
#請加入語法
