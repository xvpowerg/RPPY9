import re
str1="abcd abcdd abcb abc"
print(re.findall(r" ", str1))#請填寫規則
print(re.findall(r" ",str1))#請填寫規則
print(re.findall(r" ",str1))#請填寫規則
print(re.findall(r" ", str1))#請填寫規則
print(re.findall(r" ", str1))#請填寫規則
print(re.findall(r" ",str1))#請填寫規則
