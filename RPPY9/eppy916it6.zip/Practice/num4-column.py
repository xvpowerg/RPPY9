import numpy as np
a = np.arange(12).reshape(3, 4)
print(a)
print("---------------")
#請加入語法
print("---------------")
b=np.arange(12,24).reshape(3, 4)
print(b)
print("---------------")
#請加入語法
print(c)
print("---------------")
