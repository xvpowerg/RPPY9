import re
ptn = " " #請填寫規則     
print(re.findall(ptn, "dog ran  runs to cat rain")) 
