import re
string1="1dog  cat2  3rabbit "
print(re.findall(r" ",string1)) #請填寫規則
print(re.findall(r" ",string1)) #請填寫規則
print(re.findall(r" ",string1)) #請填寫規則
print(re.findall(r" ",string1))#請填寫規則
