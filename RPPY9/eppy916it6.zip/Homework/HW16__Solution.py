import csv
f = open(".\HW11__Data.csv","r",encoding='UTF-8')
map1=input("請輸入郵遞區號")
for row in csv.reader(f):
    if(row[2]==map1):
        print(row)
f.close()