str1 = "this is Python Tutorial, there"
print(str1)
search1 = "Python"
print("%s出現%d次" %(search1, str1.count(search1)))
search2= "not"
print("%s出現%d次" %(search2, str1.count(search2)))
search3="t"
print("%s出現%d次" %(search3, str1.count(search3)))
