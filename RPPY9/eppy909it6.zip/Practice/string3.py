name1 = "pcschool"
name2 = "python"
all1 = name1 + "-" + name2
print(all1)
all2 = ("pcschool" + "!") * 5
print(all2)


