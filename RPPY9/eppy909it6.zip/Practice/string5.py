str1 = "this is Python Tutorial, there"
search1 = "Python"
print(str1.find(search1))
search2= "not"
print(str1.find(search2))
search3="t"
print(str1.find(search3))
print(str1.find(search3,4))
print(str1.find(search3,11,20))
