str1 = "-"
str2 = ("a", "b", "c")
print(str1.join(str2))
str3=":".join("Python")
print(str3)
str4 = "python-java-c++-ruby"
print(str4.split('-'))
print(str4.split('-',1))
