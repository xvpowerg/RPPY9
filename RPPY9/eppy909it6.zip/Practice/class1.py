class Employee:
    pass

emp = Employee()
print(emp)
