str='hello, Python'
print(str.capitalize())
print(str.upper())
print(str.lower())
print(str.title())
print(str.swapcase())
