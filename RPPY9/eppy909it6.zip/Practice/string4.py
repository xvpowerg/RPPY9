str="This is Python,That is Java;This is SQLite,That is MySQL"
print("原本的字串:",str)
print()
print("is 替換為-:"+str.replace("is","-"))
print()
str="This is Python,That is Java;This is SQLite,That is MySQL"
print("原本的字串:",str)
print()
print("加上參數值2:"+str.replace("is","-",2)) 
print()
