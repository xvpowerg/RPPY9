s = "0123456"
print("字串內容:"+s)
print("字串位址:"+str(id(s)))
s = s[:3] + "C" + s[4:]
print("字串內容:"+s)
print("字串位址:"+str(id(s)))
