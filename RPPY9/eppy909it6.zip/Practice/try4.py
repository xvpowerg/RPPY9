s = "0123456"
print("字串內容:"+s)
print("字串位址:"+str(id(s)))
#print(s.replace("3","U"))
s = s.replace("3","U")
print("字串內容:"+s)
print("字串位址:"+str(id(s)))

