class Employee:
    pass

emp = Employee()
emp.name = "Sean"
emp.salary = 50000

print('==Employee information==')
print('Name: ', emp.name)
print('Salary: ', emp.salary)

emp2 = Employee()
emp2.name = "David"

print('==Employee information==')
print('Name: ', emp2.name)
print('Salary: ', emp2.salary)
