import turtle

sean = turtle.Turtle()
sean.shape('turtle')
sean.shapesize(2)
sean.pencolor('red')
sean.fillcolor('blue')
sean.pensize(2)

for i in range(1,5):
    sean.forward(100)
    sean.right(90)
