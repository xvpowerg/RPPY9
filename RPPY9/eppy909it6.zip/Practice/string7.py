#str='Python123'
str='123'
#str='   '
print(str.isalnum())
print(str.isalpha())
print(str.isdigit())
print(str.istitle())
print(str.isupper())
print(str.islower())
print(str.isspace())
