#建立一個物件類別
class user:
    userName = "unknown"
    passwd = "123456"
    #定義(建構子)物件函數 初始化物件内容
    def __init__(self,newUserName,newPasswd):
        self.userName = newUserName
        self.passwd = newPasswd
    def toString(self):
        print("帳號:",self.userName,"密碼：",self.passwd)
#主要程式
#建立一個list物件,用來存資料
objectUser = []
#建立一個選單list
memu = ["1.顯示所有帳號","2.查詢/修改/删除帳號","3.增加新帳號","4.退出程式"]
flag = 1
while(flag):
    print("\n帳號管理系統")
    #列出選單選項
    for m in memu:
        print(m)
    #取得選單選項
    num = input("請輸入要執行的項目：")
    num = num.split(".")
    #把輸入的字串轉成整數型態
    askForNum = int(num[0])
    #1.顯示所有帳號
    if(askForNum == 1):
        for num1 in objectUser:
            num1.toString()
    
    #2.查詢/修改/删除帳號
    elif (askForNum == 2):
        findUser = input("請輸入要查詢的帳戶")
        #去搜尋 objectUser 是否存在該帳號
        flag2 = 0
        for num2 in objectUser:
            #如果帳號存在
            if(num2.userName == findUser):
                flag2 = 1
                print("帳號己經登記了！！！")
                print("請選擇選項\n")
                ww = print("1.修改帳號\n2.删除帳號\n")
                aa = input("請選擇選項：")
                #如果是選 1.修改帳號
                if(aa == "1"):
                    temp2Name = input("請輸入新的帳號：")
                    temp2Passwd = input("請輸入新的密碼：")
                    num2.userName = temp2Name
                    num2.passwd = temp2Passwd
                    break
                # 如果是選 2.删除帳號
                if(aa == "2"):
                    objectUser.remove(num2)
                    break
            #如果帳號不存在
        if(flag2 == 0):
            print("這個帳號不存在！！！")
    #3.增加新帳號
    elif (askForNum == 3):
        newUser = input("請輸入新的帳號：")
        newPass = input("請輸入新的密碼：")
        tempUser = user(newUser,newPass)
        objectUser.append(tempUser)
        print("已成功增加帳號！")
    #4.退出程式
    elif (askForNum == 4):
        flag = 0
        print("己經退出程式！！！")
        break
    else:
        print("輸入格式不對，請重新輸入！！！")
