import pandas021a
#請加入語法
print(is_2002.head())
#請加入語法
print(gap1_2002.shape)
print(gap1_2002.head())