import pandas as pd
df = pd.DataFrame({'A': [1, 2, 3],'B': ['a', 'b', 'f']})
#請加入語法
print(x)
print("------------")
df = pd.DataFrame({'A': [1, 2, 3],'B': ['a', 'b', 'f']})
other = pd.DataFrame({'A': [1, 3, 3, 2], 'B': ['e', 'f', 'f', 'e']})
#請加入語法
print(x4)
print("------------")
other = pd.DataFrame({'C': [1, 3, 3, 2],'D': ['e', 'f', 'f', 'e']})
#請加入語法
print(x5)
print("------------")