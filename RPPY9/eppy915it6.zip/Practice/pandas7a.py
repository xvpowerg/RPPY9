import pandas as pd
df1 = pd.read_csv('ex1.csv')
print(df1)
print("-----")
df2 = pd.read_csv('ex2.csv')
print(df2)
print("-----")
#請新增/修改
print(df3)
print("-----")
#請新增/修改
print(df4)
print("-----")
df5 = pd.read_csv('ex2.csv',names=list('abcde'),index_col='e')
print(df5)
print("-----")