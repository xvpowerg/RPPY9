import pandas021a
continents = ['Asia','Africa', 'Americas', 'Europe']
#請加入語法
print(gapminder_Ocean.shape)