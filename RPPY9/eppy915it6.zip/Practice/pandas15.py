import pandas as pd
import numpy as np
dates=pd.date_range('20180516',periods=6)
df=pd.DataFrame(np.arange(24).reshape(6,4),index=dates,columns=['a','b','c','d'])
#請新增/修改
print("------------")
#請新增/修改
print("------------")
#請新增/修改
print("------------")
#請新增/修改
print("------------")
