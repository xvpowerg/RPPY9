import pandas as pd
import data1
df3 = pd.DataFrame(data1.data1,
                  columns = ["name", "population"],
                  index = data1.data1["city"])
print(df3)
#請新增/修改
df4= pd.DataFrame(data1.data1)
print(df4)
#請新增/修改
