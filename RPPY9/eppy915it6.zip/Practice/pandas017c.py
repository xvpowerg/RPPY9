import pandas as pd
url = 'http://bit.ly/imdbratings'
df1 = pd.read_csv(url)
print(df1.head())
print("--------------")
#請加入語法
print(df2.head())
print("--------------")
#請加入語法
print(df3.head())
print("--------------")
columns = ['content_rating', 'duration']
#請加入語法
print(df4.head())
print("--------------")