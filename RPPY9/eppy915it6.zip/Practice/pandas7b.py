import pandas as pd
df1 = pd.read_csv('ex3.csv')
print(df1)
print("-----")
#請新增/修改
print(df2)
print("-----")
#請新增/修改
print(df3)
print("-----")
df4 = pd.read_csv('ex4.csv',na_values={'message':['foo','NA'],'something':['two']})
print(df4)
print("-----")