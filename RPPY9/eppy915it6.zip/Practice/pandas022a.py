import pandas as pd
start = pd.datetime(2018, 10, 10)
end = pd.datetime(2018, 12, 25)
#請加入語法
print(a)
print("-------------")
print(b)
print("-------------")
print(c)
print("-------------")