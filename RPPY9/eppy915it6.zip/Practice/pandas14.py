import pandas as pd
fruits=pd.read_csv("https://goo.gl/DOw6pe")
#請新增/修改
