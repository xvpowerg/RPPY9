import pandas as pd
import numpy as np
df1 = pd.DataFrame(np.random.randn(10,2),index=[1,4,6,2,3,5,9,8,0,7],columns = ['col2','col1'])
print(df1)
print("--------------")
#請加入語法
print(df2)
print("--------------")
#請加入語法
print(df3)
print("--------------")
#請加入語法
print(df4)
print("--------------")