import pandas021a
#請加入語法
print(gap_2002 .shape)
#請加入語法
print(gap2.shape)