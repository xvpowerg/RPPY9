import pandas021a
years = [1952, 2007]
print(pandas021a.gap1.year.isin(years))
#請加入語法
print(gapminder_years.shape)