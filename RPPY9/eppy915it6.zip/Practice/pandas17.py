import pandas as pd
groups = ["Python", "Django", "Sqlite", "Numpy", "Security", "Pandas"]
numbers = [59, 9, 19, 14, 6, 77]
group_dict = {
"groups": groups,
"numbers": numbers
}
df1 = pd.DataFrame(group_dict)
print (df1)
print("------------")
#請新增/修改
print("------------")
#請新增/修改
print("------------")
#請新增/修改
print("------------")
#請新增/修改
print("------------")
#請新增/修改
print("------------")
#請新增/修改