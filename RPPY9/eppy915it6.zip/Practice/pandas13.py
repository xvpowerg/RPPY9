import pandas as pd
import data1
df = pd.DataFrame(
data1.data1,
columns = ["name", "city", "population"],
index=data1.data2)
#請新增/修改
print("-------")
#請新增/修改
print("-------")
#請新增/修改
print("-------")
list1=["city","name"]
#請新增/修改
print("-------")