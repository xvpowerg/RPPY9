import pandas as pd
df = pd.DataFrame({'A': [1, 2, 3],'B': ['a', 'b', 'f']})
#請加入語法
print(x)
print("------------")
df2 = pd.DataFrame({'A': [1, 2, 3],'B': [1, 4, 7]})
#請加入語法
print(x2)
print("------------")
#請加入語法
print(x3)
print("------------")