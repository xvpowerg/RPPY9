str1="string1"
for a in str1:
    print(a)
print("-----")
list1=[1,2,3,4,5,'a']
for b in list1:
    print(b)
print("-----")
