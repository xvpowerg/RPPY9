import modu
ob1=modu.test1( )  #create object
modu.fun1( )
'''
因權限因素不能呼叫使用主程式
'''
