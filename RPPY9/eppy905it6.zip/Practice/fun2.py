def func_sum(a, b):
    c = a + b
    return(c)
z = func_sum(10, 15)
#請問z的內容是多少?