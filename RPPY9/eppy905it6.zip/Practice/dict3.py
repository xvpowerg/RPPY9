dict1={'a':100,'b':200, 'c':300}
print(dict1)
#如何新增資料?
print(dict1)
