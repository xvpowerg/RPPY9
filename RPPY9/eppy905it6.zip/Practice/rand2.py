import  random
a=random.sample('abcdefghij',3) 
print(a)
b=random.choice ( ['apple', 'pear', 'peach', 'orange', 'lemon'] )
print(b)
items = [1, 2, 3, 4, 5, 6]
random.shuffle(items)
print(items)
