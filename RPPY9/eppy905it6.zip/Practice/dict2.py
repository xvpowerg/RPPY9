dict1={'a':100,'b':200, 'c':300}
print(dict1)
print(dict1.keys())
print(dict1.values())
