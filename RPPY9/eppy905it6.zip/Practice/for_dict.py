dict1={'a':100,'b':200,'c':300}
for c in dict1.keys():
    print(c)
print("-----")
for c in dict1.keys():
    print(dict1[c])
print("-----")
for c in dict1:
    print(c)
print("-----")
for c in dict1.values():
    print(c)
