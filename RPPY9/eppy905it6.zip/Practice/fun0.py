def func_sum( ):
    print("呼叫函數")
    return( )
print("呼叫前")
func_sum( )
print("呼叫後")
