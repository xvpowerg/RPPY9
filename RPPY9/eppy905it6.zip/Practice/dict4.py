dict1={'a':100,'b':200, 'c':300}
print(dict1)
#如何進行更新?
print(dict1)
