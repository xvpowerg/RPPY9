a=5
def func_sum():
   #a=10
   print("函數內:",a)
   return()
print("函數外1:", a)
func_sum()
print("函數內2:", a)