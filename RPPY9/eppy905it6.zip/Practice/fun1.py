def func_sum(a, b):
    c = a + b
    print(c)
    return( )
func_sum(10, 15)
