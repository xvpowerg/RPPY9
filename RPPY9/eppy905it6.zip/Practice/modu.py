class test1:
    def __init__(self):
        print("create")
def fun1( ):
    print("function")
    return( )
#如果主程式不放在條件分析內呢?
if __name__ == '__main__':
    print("testmu!")
