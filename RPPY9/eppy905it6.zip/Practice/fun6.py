def func_a( ):
    return 1, 2, 3, 4
temp = func_a( )
print(type(temp))
