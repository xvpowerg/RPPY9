dict1={'a':100,'b':200, 'c':300}
print(dict1)
del dict1['c']
print(dict1)
print  ('c' in dict1.keys())
print  ('a' in dict1.keys())


