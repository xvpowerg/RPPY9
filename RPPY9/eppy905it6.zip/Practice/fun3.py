a=5
def func_sum( ):
   a=10
   print("函數內:",a)
   return( )
print("函數外1:", a)
func_sum( )
print(func_sum.__class__)
print("函數外2:", a)
