a=5
def func_sum( ):
   a=10
   a=a+6
   print("函數內:",a)
   return( )
func_sum( )
a += 6
print("函數外:", a)
