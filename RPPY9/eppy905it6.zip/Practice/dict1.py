dict1={'a':100,'b':200,'c':300}
print(dict1)
dict1={'a':200,'b':400,'b':300}
print(dict1)
print(dict1['a'])
print(dict1['b'])
print(dict1['d']) #不存在
