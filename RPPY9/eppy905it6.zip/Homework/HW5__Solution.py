dict = {}
num = int(input("有幾個月份："))
for i in range(num):
    temp = int(input("請輸入第%d個月的支出金額："%(i + 1)))
    dict.update({i:temp})
print("支出最多的金額為：" + str(max(dict.values())))
print("支出最少的金額為：" + str(min(dict.values())))
print("支出的總額為：" + str(sum(dict.values())))
print("支出金額由小到大排序為：" + str(sorted(dict.values())))
