import json
json1 = '{"python": "good", "gjun": 100, "python-class": true, "ICQ": null}'
json2 = json.loads(json1)
print(json2)
