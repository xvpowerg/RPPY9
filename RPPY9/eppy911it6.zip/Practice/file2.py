file = open('data.txt', 'r', encoding='UTF-8')
content = file.read()
print(content)
file.close()
print("-------------")
#如何開啟檔案與讀取?
print(content2)
file.close()

