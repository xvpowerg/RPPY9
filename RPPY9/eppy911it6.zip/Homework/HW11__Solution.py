import csv
file1 = open(".\HW8__Data.csv","r",encoding='utf-8-sig')
for row in csv.DictReader(file1,['a','b','c','d','e','f','g','h','i']):
    print(row['a'],row['b'],row['c'])
file1.close()
