import numpy as np
a = np.genfromtxt('.\HW12__Data.csv', dtype='int',delimiter=',', skip_header=1,encoding='utf-8-sig',unpack=True)
x=np.size(a, axis=0)
for i in range(x):
    if a[0,i]!=-1:
        print(a[0, i], end=' ')
        print(a[1, i], end=' ')
        y = a[3, i] + a[4, i]
        print("國小(含)之前的人數:", y)
