import numpy as np
#如何讀取檔案?
print(x)
#如何讀取檔案?
print("Value1=",y)
print("Value2=",z)
