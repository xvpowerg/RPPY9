import numpy as np
from numpy import genfromtxt
a = np.genfromtxt('data4.csv', dtype='int',delimiter=',', skip_header=1,encoding='utf-8')
x=np.size(a, axis=0)
print(x)
print(a.shape)
print(a)
#請嘗試進行資料挑選輸出
