import numpy as np
a = np.array([[30,40,70],[80,20,10],[50,90,60]])
print(a)
print()
#請修改
print(b)
print()
#請修改
print(b)
print()
#請修改)
print(b)
print()
