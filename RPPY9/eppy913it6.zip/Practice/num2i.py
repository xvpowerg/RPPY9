import numpy as np
from numpy import genfromtxt
#如何讀取檔案?
print(a)
help(np.savetxt)
#如何寫入檔案?
#如何讀取檔案?
print(b)
#如何寫入檔案?
