import numpy as np
d=np.array([8397,8393,8389,8376,8378,8395,8411,8409,8406,8413,8408,8408,8414,8421,8411,8392,8404])
print(d)
b=1
for a in d:
   if b>12:
       c="107"
       print("民國"+str(c)+"年"+str(b-12)+"月總人數:"+str(a))
   else:
       c="106"
       print("民國"+str(c)+"年"+str(b)+"月總人數:"+str(a))
   b=b+1
print("最大值為：",np.max(d))
print("最小值為：",np.min(d))
print("中位數為：",np.median(d))
print("平均值為：",np.mean(d))