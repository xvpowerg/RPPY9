import numpy as np
a = np.array([-1.7, 1.5, -0.2, 0.6, 10])
print(a)
print()
#請修改
print(b)
print()
#請修改
print(c)
print()