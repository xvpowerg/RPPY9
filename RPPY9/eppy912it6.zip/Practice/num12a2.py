import numpy as np
a = np.array([4,5,6])
print(a)
print( )
#請修改
print(b)
print( )
c = np.array([1,2,3])
#請修改
print(d)
print( )
#請修改
print(h)
