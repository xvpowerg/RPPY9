import numpy as np
a = np.array( [6, 7, 8, 9] )
b = np.arange( 4 )
#請加入語法
print("a=>",a)
print("b=>",b)
print("c=>",c)
#請加入語法
print("d=>",d)
f = np.array([5, -1, 3, 9, 0])
#請加入語法
print("f=>",f)
