import numpy as np
a = np.array([1.0,5.45, 123, 0.567, 25.532])
print(a)
print()
#請修改
print(b)
#請修改