import numpy as np
a = np.array([1,2,3,4])
#請修改
print(b)
print()
wts = np.array([4,3,2,1])
#請修改
print(b)
print()
#請修改
print(b)
print()

