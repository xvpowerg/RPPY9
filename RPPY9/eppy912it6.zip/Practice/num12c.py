import numpy as np
a = np.array([10,20,30])
b = np.array([3,5,7])
print(a)
print()
#請修改
print(c)
print()
#請修改
print(d)
print()