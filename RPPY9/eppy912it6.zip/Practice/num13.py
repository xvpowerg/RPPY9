import numpy as np
a = np.array([[0, 30,45],[60,75,90]])
print(a)
print("---------------")
#請修改
print(b)
print("---------------")
#請修改
print(b)
print("---------------")
#請修改
print(b)
print("---------------")
