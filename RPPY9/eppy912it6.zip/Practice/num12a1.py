import numpy as np
a = np.array([[1,2,3],[4,5,6],[7,8,9]])
b = np.array([10,10,10])
#請修改
print(c)
print()
#請修改
print(d)
print()
#請修改
print(f)
print()
#請修改
print(g)
print()
