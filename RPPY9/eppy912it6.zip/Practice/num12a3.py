import numpy as np
a = np.array([0.25, 1.33, 1, -0.1, 100])
print(a)
print( )
#請修改
print(b)
print( )
