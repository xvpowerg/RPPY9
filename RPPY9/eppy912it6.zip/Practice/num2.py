import numpy as np
l = [[1, 2, 3],
     [2, 3, 4]]
#請嘗試

