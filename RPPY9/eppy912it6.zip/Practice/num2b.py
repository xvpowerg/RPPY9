import numpy as np
#如何設定規劃x陣列?
print(x)
print("-----")
#如何設定規劃x陣列?
print(x)
print("-----")
#如何設定規劃x陣列?
print(c)
