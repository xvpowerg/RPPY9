import numpy as np
a = np.array([[1,2,3],[4,5,6]])
print(a)
print(a.shape)
print( )
#如何調整大小?
print(b)
print(b.shape)
print( )
#如何設定資料?
print(b)
print(b.shape)
print(a.shape)
