import numpy as np
print(np.around([1.5, 2.5], decimals=0))
print(np.around([-0.5, 0.5], decimals=0))

