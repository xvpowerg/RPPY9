class Employee():
    def __init__(self, name, salary=20000):
        self._name = name
        if salary >=20000:
            self._salary = salary
        else:
            self._salary = 20000
    @property   # 讀
    def salary(self): 
        return self._salary
    @salary.setter   # 寫
    def salary(self, v):        
        if v > 20000:
            self._salary = v
        else:
            print('薪水不得低於最低工資!')
    @salary.deleter  # 刪除
    def salary(self): 
        del self._salary

emp1 = Employee("Sean", 50000)
emp2 = Employee("David")
print('======加薪前=====')
print('員工一薪水:', emp1.salary)
print('員工二薪水:', emp2.salary)

emp1.salary = 55000
emp2.salary = 17000
print('======加薪後=====')
print('員工一薪水:', emp1.salary)
print('員工二薪水:', emp2.salary)
