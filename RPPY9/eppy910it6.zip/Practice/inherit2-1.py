class Employee:
    __count = 0
    company = '巨匠電腦'
    phone = '(02)2311-4537'

    def __init__(self, name, salary=20000):
        Employee.__count+=1
        self.__id = Employee.__count
        self.__name = name
        if salary >=20000:
            self.__salary = salary
        else:
            self.__salary = 20000

    def getTotal():
        return Employee.__count
    
    def getID(self):
        return self.__id

    def getName(self):
        return self.__name

    def getSalary(self):
        return self.__salary    

    def raiseSalary(self, increase):
        if increase >0:
            self.__salary += increase
        else:
            print('加薪金額需大於0')
    
    def printInfo(self):
        print('==員工資訊==')
        print('員工編號:', self.__id)
        print('姓名:', self.__name)
        print('薪水:', self.__salary)
        print('電話:', self.phone)

class Manager(Employee):
    def __init__(self, name, dept, salary=50000):
        super(Manager, self).__init__(name, salary)
        self.__department = dept

    def getDepartment(self):
        return self.__department
    
    def setDepartment(self, dept):
        self.__department=dept

    def printInfo(self):
        super(Manager, self).printInfo()
        print('部門:', self.__department)

emp1 = Employee("Sean", 30000)
emp2 = Manager("David", "Sales")

print(Employee.company+'員工資訊')
print('員工人數:', Employee.getTotal())
emp1.printInfo() 
emp2.printInfo()
