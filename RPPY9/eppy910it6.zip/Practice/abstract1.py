from abc import ABCMeta, abstractmethod
class Employee(metaclass=ABCMeta):
    def __init__(self, name):
        self._name = name
        
    @abstractmethod
    def work(self):
        pass

    def teabreak(self):
        print(self._name+'在喝咖啡!')
    
class Manager(Employee):
    def __init__(self, name):
        super(Manager, self).__init__(name)

    def work(self):
        print(self._name+'在開會!')

class Engineer(Employee):
    def __init__(self, name):
        super(Engineer, self).__init__(name)

    def work(self):
        print(self._name+'在寫 Python!')

class Sales(Employee):
    def __init__(self, name):
        super(Sales, self).__init__(name)

    def work(self):
        print(self._name+'在電話行銷!')

emp1 = Manager('Amy')
emp2 = Engineer('Sean')
emp3 = Sales('David')
#emp4 = Employee('Nicole')

emp1.work()
emp2.work()
emp3.work()

emp1.teabreak()
emp2.teabreak()
emp3.teabreak()
