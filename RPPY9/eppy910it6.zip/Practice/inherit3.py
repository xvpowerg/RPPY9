class S(object):
    def method1(self):
        print('S.method1')
        
    def method2(self):
        print('S.method2')
        
class A(S):
    def method3(self):
        print('A.method3')
        
class B(S):
    def method2(self):
        print('B.method2')
        
    def method3(self):
        print('B.method3')
        
class C(A, B):
    value = 0
    def method4(self):
        print('C.method4')

c = C()
c.method4() 
c.method3()
c.method2()
c.method1()
