class Employee():
    def __init__(self, name, salary=20000):
        self._name = name
        if salary >=20000:
            self._salary = salary
        else:
            self._salary = 20000
    
    def get_salary(self): # 讀
        return self._salary
    def set_salary(self, v): # 寫
        if v > 20000:
            self._salary = v
        else:
            print('薪水不得低於最低工資!')
    def del_salary(self): # 刪除
        del self._salary
    salary = property(get_salary, set_salary, del_salary) # salary

emp1 = Employee("Sean", 50000)
emp2 = Employee("David")
print('======加薪前=====')
print('員工一薪水:', emp1.salary)
print('員工二薪水:', emp2.salary)

emp1.salary = 55000
emp2.salary = 17000
print('======加薪後=====')
print('員工一薪水:', emp1.salary)
print('員工二薪水:', emp2.salary)
