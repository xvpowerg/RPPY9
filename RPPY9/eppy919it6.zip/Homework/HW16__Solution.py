import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei'] 
plt.rcParams['axes.unicode_minus'] = False  
df=pd.read_csv('HW16__Data.csv',encoding='utf-8')
df2=pd.DataFrame(df)
df3=df2.drop(['交流道','進出口','週2-4'],axis=1)
df4 = df3.groupby('路線方向').sum()
mask1 = df4['週六'] > 2000000
mask2 = df4['週日'] > 2000000
df5=df4[(mask1 & mask2)]
df5.index=df5.index.str.replace('國1北向路段','1北向')
df5.index=df5.index.str.replace('國1南向路段','1南向')
df5.index=df5.index.str.replace('國3北向路段','3北向')
df5.index=df5.index.str.replace('國3南向路段','3南向')
print(df5.index)
df5.plot.bar()
plt.xlabel('路線編號')
plt.ylabel('車流量')
plt.show()
#===========
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
fontPath = r'C:\\WINDOWS\\Fonts\\simsun.ttc'
font30 = fm.FontProperties(fname=fontPath, size=18)
plt.rcParams['axes.unicode_minus'] = False  
df=pd.read_csv('HW16__Data.csv',encoding='utf-8')
df2=pd.DataFrame(df)
df3=df2.drop(['交流道','進出口','週2-4'],axis=1)
df4 = df3.groupby('路線方向').sum()
mask1 = df4['週六'] > 2000000
mask2 = df4['週日'] > 2000000
df5=df4[(mask1 & mask2)]
df5.index=df5.index.str.replace('國1北向路段','1北向')
df5.index=df5.index.str.replace('國1南向路段','1南向')
df5.index=df5.index.str.replace('國3北向路段','3北向')
df5.index=df5.index.str.replace('國3南向路段','3南向')
print(df5.index)
df5.plot.bar()
plt.legend(prop=font30)
plt.xticks(fontproperties=font30)
plt.xlabel('路線編號', fontproperties=font30)
plt.ylabel('車流量', fontproperties=font30)
plt.show()