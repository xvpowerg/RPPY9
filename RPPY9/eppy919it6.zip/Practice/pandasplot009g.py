import matplotlib.pyplot as plt
import pandasplot009a
purchase_patterns = pandasplot009a.sales[['ext price','date']]
print(purchase_patterns.head())
purchase_patterns = purchase_patterns.set_index('date')
print(purchase_patterns.head())
#請加入語法
plt.show()
fig = purchase_plot.get_figure()
fig.savefig("total-sales.png")