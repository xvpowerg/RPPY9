import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
df = pd.DataFrame(np.random.randn(10,4),index=pd.date_range('1/1/2018',periods=10), columns=list('ABCD'))
#請加入語法