import pandas_group as df1
import numpy as np
#請加入語法
print (grouped.get_group(2017))
#請加入語法
print(grouped['Points'].agg(np.mean))
#請加入語法
print(grouped2.agg(np.size))
print(grouped2['Points'].agg([np.sum, np.mean, np.std]))
