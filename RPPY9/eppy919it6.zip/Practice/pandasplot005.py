import matplotlib.pyplot as plt
import numpy as np
X = np.linspace(-np.pi, np.pi, 256, endpoint=True)
Y = np.cos(X)
#請加入語法
plt.title('subplot(2,2,(3,4))')
plt.show()