import pandas as pd
#請加入語法
print(a)
print("-------------")
#請加入語法
print(a)
print("-------------")
s1 = pd.Series(a)
print(s1)
print("-------------")