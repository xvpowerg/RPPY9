import matplotlib.pyplot as plt
import pandasplot009a
customers = pandasplot009a.sales[['name','category','ext price','date']]
print(customers.head())
#請加入語法
my_plot.set_xlabel("Customers")
my_plot.set_ylabel("Sales")
plt.show()