import matplotlib.pyplot as plt
import pandasplot009a
customers = pandasplot009a.sales[['name','category','ext price','date']]
print(customers.head())
category_group=customers.groupby(['name','category']).sum()
print(category_group.head())
print(category_group.unstack().head())
#請加入語法
my_plot.set_xlabel("Customers")
my_plot.set_ylabel("Sales")
my_plot.legend(["Total","Belts","Shirts","Shoes"],
               loc=9,ncol=4)
plt.show()