import pandas031
pd1=pandas031.pd
one1=pandas031.one
two1=pandas031.two
#請加入語法
print(pd2)
print("--------------------")
#請加入語法
print(pd3)
print("--------------------")
#請加入語法
print(pd4)
print("--------------------")
#請加入語法
print(pd5)
print("--------------------")