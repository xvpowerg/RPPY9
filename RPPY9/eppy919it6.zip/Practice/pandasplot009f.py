import matplotlib.pyplot as plt
import pandasplot009a
purchase_patterns = pandasplot009a.sales[['ext price','date']]
print(purchase_patterns.head())
#請加入語法
purchase_plot.set_title("Purchase Patterns")
purchase_plot.set_xlabel("Order Amount($)")
purchase_plot.set_ylabel("Number of orders")
plt.show()