import matplotlib.pyplot as plt
import pandasplot009a
customers = pandasplot009a.sales[['name','ext price','date']]
print(customers.head())
print("----------5-----------")
#請加入語法
print(customer_group.size())
print("----------6-----------")
sales_totals = customer_group.sum()
#請加入語法
plt.show()