import matplotlib.pyplot as plt
import pandasplot009a
customers = pandasplot009a.sales[['name','ext price','date']]
print(customers.head())
print("----------5-----------")
customer_group = customers.groupby('name')
print(customer_group.size())
print("----------6-----------")
sales_totals = customer_group.sum()
#請加入語法
my_plot.set_xlabel("Customers")
my_plot.set_ylabel("Sales ($)")
plt.show()