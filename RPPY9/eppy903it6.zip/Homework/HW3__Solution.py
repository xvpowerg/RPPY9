print("若失敗五次就會退出遊戲")
a=0
x=str(input("請輸入一個字串 "))
while a<5:
 
 y="請輸入-"+x[-1]+"-的字串"
 
 z=input(y)
 
 if(z[0]==x[-1]):
     
     x = str(x)+"-"+str(z)
     
     print("上一個字串是 ", x)
 
 else:
     
     a += 1
     
     z1 = "錯誤" + str(a) + "次,請再輸入-" + x[-1] + "-的字串"
     
     print(z1)
