str1 = "this is Python Tutorial, there"
search1 = "Python"
print(str1[-2])
#請進行搜尋與輸出
search2= "not"
#請進行搜尋與輸出
search3="t"
#請進行搜尋與輸出
#請進行搜尋與輸出
#請進行搜尋與輸出
