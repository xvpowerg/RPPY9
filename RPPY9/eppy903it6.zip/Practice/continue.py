i = ['a', 'b', 'c', 'd']
for   j   in   i:
#如何continue
    print(j)
