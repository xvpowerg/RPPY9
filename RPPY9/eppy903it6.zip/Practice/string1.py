str3= """
多行
字串
"""
str4= '''
多行
字串'''
print("字串1:", str3)
print("字串2:", str4)