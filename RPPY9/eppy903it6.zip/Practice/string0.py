#請定義字串樣式
print(str)
#請定義字串樣式
print(str)
#請定義字串樣式
print(str)
