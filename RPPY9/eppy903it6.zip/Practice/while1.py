a = 6
while : # 迴圈的條件分析
    print(a)
       #迴圈的控制變數調整
print("離開後a為",a)
