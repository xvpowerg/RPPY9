str1 = "-"
str2 = ("ab", "cd", "xyz")
print(str1.join(str2))
str3=":".join("Python")
print(str3)
str4 = "python-java-c++-ruby-php-mysql"
print(str4.split('-'))
print(str4.split('-',3))
print(str4.split('c++'))  #起始由0開始
