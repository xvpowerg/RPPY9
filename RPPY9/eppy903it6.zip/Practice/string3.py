mystring1="Hello World"
print(mystring1[0])
print(mystring1[2])
print(mystring1[-1])
print(mystring1[-2])
print(mystring1[2:])
print(mystring1[:3])
print(mystring1[1:4])
