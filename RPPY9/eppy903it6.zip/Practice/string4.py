str="This is Python,That is Java;This is SQLite,That is MySQL"
print("原本的字串:",str)
print()
#請加入取代的語法
print()
str="This is Python,That is Java;This is SQLite,That is MySQL"
print("原本的字串:",str)
print("原本的字串id:",id(str))
print()
#請加入取代的語法
print()
str=str.replace(" is "," - ",2)
print("原本的字串:",str)
print("原本的字串id:",id(str))