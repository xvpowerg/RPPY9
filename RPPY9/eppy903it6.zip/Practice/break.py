i = ['a', 'b', 'c', 'd']
for   j   in   i:
#如何break
    print(j)
