print("兩個參數")
for i in range(,):
    print(i)
print("離開後i為",i)