Height = float(input("請輸入身高，單位為公分:"))
Weight = float(input("請輸入體重，單位為公斤:"))

BMI = Weight/((Height/100)**2)

Status = ""

if BMI < 18.5:
    Status = "太輕"
elif 18.5<=BMI<25:
    Status = "正常"
elif 25<=BMI<30:
    Status = "過重"
else:
    Status = "肥胖"

print("your BMI is " + str(BMI) + " 您的體重" + Status)

