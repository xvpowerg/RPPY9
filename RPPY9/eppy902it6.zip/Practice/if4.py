a=14 #條件分析/邏輯分析
if a>=12  a<18 :
    print("ok-1")
else:
    print("cancel- 1")
if 12a<18:
    print("ok-2")
else:
    print("cancel- 2")
if  a>18:
    print("ok-3")
else:
    print("cancel- 3")
