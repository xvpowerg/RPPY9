a,b,c= # 給他們內容
d,f=# 給他們內容
print (a*b)
print (a**b)
print (a % 3)
print (d + f)
print (c//b)
print (a/b)

