a=21 #條件分析/關係比較分析
if :
    print("大於18")
elif :
    print("大於12")
else:
    print("小於12")
