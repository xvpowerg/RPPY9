a = input("輸入字串: ")
#請輸出
a = input("輸入整數: ")
#請輸出
a = float(input("float輸入浮點數: "))
#請輸出
a = int(input("int輸入整數:"))
#請輸出
a = int(input("int輸入字串:"))
#請輸出