c = int(input("int輸入c:"))
d = int(input("int輸入d:"))
h = float(input("float輸入h:"))
i = float(input("float輸入i:"))
#加總
#輸出並且比較兩者不同

