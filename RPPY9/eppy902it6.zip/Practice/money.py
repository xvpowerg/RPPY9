money = 50000
cell = int(input("請輸入手機金額："))
#請輸入計算式
print("剩餘款為：" + str(money))
