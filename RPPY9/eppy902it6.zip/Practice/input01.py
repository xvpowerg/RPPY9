a = input("輸入整數1a: ")
b = input("輸入整數1b: ")
c = int(input("int輸入c:"))
d = int(input("int輸入d:"))
#加總
#輸出並且比較兩者不同

