import pandas as pd
money1=pd.read_csv("2017.csv")
data1=money1.replace('…',0)
data2=data1.replace('—',0)
del data2['年度']
del data2['經常性薪資-女/男']
del data2['專業人員-女/男']
del data2['技術員及助理專業人員-女/男']
del data2['事務支援人員-女/男']
del data2['服務及銷售工作人員-女/男']
del data2['技藝_機械設備操作及組裝人員-女/男']
del data2['基層技術工及勞力工-女/男']
data2 = data2.rename(columns={'經常性薪資-薪資': '經常性'})
data2 = data2.rename(columns={'專業人員-薪資': '專業人員'})
data2 = data2.rename(columns={'技術員及助理專業人員-薪資': '技術員及助理'})
data2 = data2.rename(columns={'事務支援人員-薪資': '事務人員'})
data2 = data2.rename(columns={'服務及銷售工作人員-薪資': '服務銷售'})
data2 = data2.rename(columns={'技藝_機械設備操作及組裝人員-薪資': '機械設備操作'})
data2 = data2.rename(columns={'基層技術工及勞力工-薪資': '基層勞力'})
print(data2)