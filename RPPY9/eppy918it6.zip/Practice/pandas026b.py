import pandas as pd
import numpy as np
a = pd.MultiIndex.from_arrays(
    [['Python', 'Java', 'Python', 'Java', 'Python'], ['A', 'A', 'B', 'C', 'B']],
    names=['language', 'index'])
df4 = pd.DataFrame(np.random.randint(1, 10, (5, 5)), columns=a)
print(df4)
print("-----------------")
#請加入語法
print("-----------------")
#請加入語法