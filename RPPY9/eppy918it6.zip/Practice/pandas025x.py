import pandas025
df2=pandas025.df1
print(type(df2.groupby('key1')))
print(type(df2['data1'].groupby(df2['key1'])))
#請加入語法