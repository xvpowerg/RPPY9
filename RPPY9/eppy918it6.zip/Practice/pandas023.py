import pandas as pd
s1 = pd.Series(range(10))
#請加入語法
print(s1)
print("--------------")
print(s2)
print("--------------")
print(s3)
print("--------------")
