import pandas025
df2=pandas025.df1
#請加入語法
print(grouped2.size())
#請加入語法
print(grouped3.mean())
print(grouped3.mean().unstack())


