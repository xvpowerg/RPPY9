import pandas027
import numpy as np
grouped = pandas027.df.groupby('Team')
