import pandas as pd
indexdate = pd.date_range('2018-09-25', periods=10)
#請加入語法
print(s1)
print("--------------")
print(s2)
print("--------------")
print(s3)
print("--------------")
print(s4)
print("--------------")
print(s5)
print("--------------")