import pandas028
a=pandas028.df.set_index('date').resample('M')["ext price"].sum()
print(a)
print("-------------")
b=pandas028.df.set_index('date').groupby('name')["ext price"].resample("M").sum()
print(b)