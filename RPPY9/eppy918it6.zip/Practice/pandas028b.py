import pandas028
a=pandas028.df.groupby(['name', pandas028.pd.Grouper(key='date', freq='M')])['ext price'].sum()
print(a)
print("-------------")
b=pandas028.df.groupby(['name', pandas028.pd.Grouper(key='date', freq='A-DEC')])['ext price'].sum()
print(b)