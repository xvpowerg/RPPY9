import pandas as pd
data = pd.DataFrame({'food':['bacon','pulled pork','bacon','Pastrami',
            'Corned beef','Bacon','pastrami','honey ham','nova lox'],
                  'ounces':[4,3,12,6,7.5,8,3,5,6]})
meat_to_animal = {
    'bacon':'pig',
    'pulled pork':'pig',
    'astrami':'cow',
    'corned beef':'cow',
    'honey ham':'pig',
    'nova lox':'salmon'    }
print(data)
print("--------------")
#請加入語法
print(data)
print("--------------")
#請加入語法
print(data)
print("--------------")