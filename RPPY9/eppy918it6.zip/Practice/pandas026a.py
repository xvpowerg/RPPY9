import pandas as pd
import numpy as np
df3 = pd.DataFrame(np.random.randint(1, 10, (5,5)), columns=['a', 'b', 'c', 'd', 'e'], index=['A', 'B', 'C', 'D', 'E'])
df3.ix[1, 1:4] = np.NaN
print(df3)
print("-----------------")  
mapping_dict = {'a':'Python', 'b':'Python', 'c':'Java', 'd':'C', 'e':'Java'}
print("size")
#請加入語法
print("count")
#請加入語法
print("sum")
#請加入語法

