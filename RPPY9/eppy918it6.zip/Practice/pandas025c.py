import pandas025a
print("-------start--------")
for group_name, group_data in pandas025a.grouped1:
    print(group_name)
    print(group_data)
#請加入語法
