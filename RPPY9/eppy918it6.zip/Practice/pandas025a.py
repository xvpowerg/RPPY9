import pandas as pd
import numpy as np
a = {'key1' : ['a', 'b', 'a', 'b', 'a', 'b', 'a', 'a'],
     'key2' : ['one', 'one', 'two', 'three', 'two', 'two', 'one', 'three'],
     'data1': [2,3,4,5,6,7,8,1],
     'data2':[8,1,2,3,5,6,7,6]}
df1 = pd.DataFrame(a)
self_def_key = [0, 1, 2, 3, 3, 4, 5, 7]
grouped1 = df1.groupby(['key1', 'key2'])
#print(grouped2.size( ))
grouped2 = df1.groupby(['key2', 'key1'])
#print(grouped3.mean( ))
#print(grouped3.mean( ).unstack( ))
#請加入語法
#print(grouped2.mean())