import pandas027
grouped = pandas027.df.groupby('Year')
for name,group in grouped:
    print(name)
    print(group)
print("------------------")
print(grouped.get_group(2014))