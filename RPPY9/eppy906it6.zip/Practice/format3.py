b=123.926
print("5*%d*" % (b))
print("6*%f*" % (b))#請修改 
print("7*%f*" % (b))#請修改 
print("8*%f*" % (b))#請修改 
