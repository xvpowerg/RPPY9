from decimal import *
print(1.1 + 2.2)
#請補充
print(0.1 + 0.1 + 0.1 - 0.3)
#請補充
print(1.20 + 1.30)
#請補充
