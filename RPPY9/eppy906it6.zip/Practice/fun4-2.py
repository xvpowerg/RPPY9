def changeme( mylist ):
   print(id(mylist))
   #請問這裡對list做了甚麼動作
   print(id(mylist))
   print ("函數內： ", mylist)
   return()
mylist = [10,20]
print(id(mylist))
changeme( mylist )
print ("執行完函數：", mylist)
