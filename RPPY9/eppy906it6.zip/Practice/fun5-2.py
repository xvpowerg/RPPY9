def printinfo( name="may", age=20 ):
   print ("Name: ", name)
   print ("Age ", age)
   print("-----------")
   return()
#請問你會傳遞那些資料到函數內? 共計五行語法
