x=y=[0,1,2]
print(x,y)
print(id(x))
print(id(y))
#x會怎麼加?
print(x,y)
print(id(x))
print(id(y))
print(x is y)
