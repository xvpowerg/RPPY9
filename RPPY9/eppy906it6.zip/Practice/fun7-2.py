def fun4(arg1,arg2='default',**arg4 ):
    print("arg1:",arg1)
    print("arg2: ",arg2)
    for each_arg2 in arg4.keys():
        print("arg4: %s=>%s" % ( each_arg2, str(arg4[each_arg2])))
fun4(1)
fun4(1, 2)
fun4(1, 2, a="b")
