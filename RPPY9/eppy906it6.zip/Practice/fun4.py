def changeme( mylist ):
    print(id(mylist))
    mylist[2]='a'
    print(id(mylist))
    print ("函數內： ", mylist)
    return( )
mylist = [10,20,30]
print(id(mylist))
changeme( mylist )
print ("執行完函數：", mylist)