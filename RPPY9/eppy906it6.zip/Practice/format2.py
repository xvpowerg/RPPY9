c='我'
print("1*%c*" % (c))
print("2*%s*" % (c))#請修改 
print("3*%s*" % (c))#請修改 
print("4*%s*" % (c))#請修改 
