x=range(100)
for i in x[::-1]:
    print(i)
for i in x[::2]:
    print(i)
for i in x[::3]:
    print(i)
for i in x[10:40:6]:
    print(i)
