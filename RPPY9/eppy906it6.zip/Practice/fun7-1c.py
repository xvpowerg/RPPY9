def fun3(*arg3):
    for each_arg in arg3:
        print ("each_arg: ", each_arg)
	print(arg3)
fun3()
print("---A---")
fun3(1)
print("---B---")
fun3(1, 2)
print("---C---")
fun3(1, 2, 3,5)
