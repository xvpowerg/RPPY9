def fun3(arg2='default',arg1,*arg3):
    print("arg1:",arg1)
    print("arg2: ",arg2)
    for each_arg in arg3:
        print ("each_arg: ", each_arg)
fun3(1)
fun3(1, 2)
fun3(1, 2, 3,5)
