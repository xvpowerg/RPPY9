a=b=[0,1,2]
print(a,b)
print(id(a))
print(id(b))
#a會怎麼加?
print(a,b)
print(id(a))
print(id(b))
print(a is b)
