values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
y = [x + 10 for x in values]
print(y)
z = [x for x in values if x % 2 == 0]
print(z)
