list = []
palindrome = []
word = '0'
def reveese_str(string):
    return string[::-1]

while word != ' ':
    word = input('請輸入字串,當您輸入為0就結束輸入:')
    list.append(word)
    if word == '0':
        break
    if word == reveese_str(word):
        palindrome.append(word)
        continue
list.remove('0')
print('顯示清單內容:'+str(list))
print('顯示清單內符合回文的字串:'+str(palindrome))
