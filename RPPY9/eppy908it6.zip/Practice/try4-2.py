num1 = 10
num2 = 0
nums = [1,3,5,7,9]
try:
    print(num1)
except:
    print('Error發生')
else:
    print('Error沒發生')
finally:
    print('結束')