class Employee():
    def __init__(self, name, salary=20000):
        self.__name = name
        if salary >=20000:
            self.__salary = salary
        else:
            print('薪水設定為最低工資!')
            self.__salary = 20000
        
    def getSalary(self):
        return self.__salary

    def raiseSalary(self, increase):
        if increase >0:
            self.__salary += increase
        else:
            raise MyError('薪水設定失敗!', '加薪金額需大於0')
        
class MyError(Exception):
    def __init__(self, cause, message):
        super(MyError, self).__init__(cause, message)
        self.cause = cause
        self.message = message
    def __str__(self):
        return self.cause + ': ' + self.message

emp1 = Employee("Sean", 50000)
emp2 = Employee("David", 15000)

print('======加薪前=====')
print('員工一薪水:', emp1.getSalary())
print('員工二薪水:', emp2.getSalary())

try:
    emp1.raiseSalary(5000)
    emp2.raiseSalary(-3000)
except Exception as e:
    print(e)
print('======加薪後=====')
print('員工一薪水:', emp1.getSalary())
print('員工二薪水:', emp2.getSalary())
