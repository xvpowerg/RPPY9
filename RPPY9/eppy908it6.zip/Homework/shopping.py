#  錢包總金額為1000元，如果購買商品總金額超過1000
#  將會引發一個金額不足的例外

shoppingcart = {'預計開銷':0 }

class insufficientError(Exception): pass

def buy(items):
    cash = 1000
    total = 0
    try:
        while cash <=1000:
            a=input("消費項目：")
            b=int(input("消費金額："))
            total += b
            if total > cash:
                raise insufficientError
            else:
                add_dic = {a: b}
                print("目前消費金額："+str(total))
                shoppingcart.update(add_dic)
    except insufficientError:
        print('已經超支了')
    finally:
        print(shoppingcart)

buy(shoppingcart)