import matplotlib
print(matplotlib.__file__)
import matplotlib.pyplot as plt
#請加入語法
x_labels = ['小', '中', '大']
x = range(len(x_labels))
y = [-3, 0, 3]
plt.scatter(x, y)
plt.xticks(x,x_labels)
plt.tick_params(axis='x', which='major', labelsize=30)
plt.show()