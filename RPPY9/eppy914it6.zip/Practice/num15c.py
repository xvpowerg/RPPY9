import numpy as np
a = np.arange(6)
print(a)
print(id(a))
#請加入語法
print(b)
print(id(b))
b.shape = 3,2
print(b)
print(a)
b[0,0] = 100
print(a) 