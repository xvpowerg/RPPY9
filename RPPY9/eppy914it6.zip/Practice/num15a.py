import numpy as np
a = np.array([0, 30, 45,60,75,90])
print(a>15)
#請加入語法
print(b)
#請加入語法
print(condition)
print( )
#請加入語法
print(b)
print (a[b])
#請加入語法
print( )