import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
# 設定字體的檔案位置，並放到fm.FontProperties裡
fontPath = r'C:\\WINDOWS\\Fonts\\simsun.ttc'
font30 = fm.FontProperties(fname=fontPath, size=30)
x_labels = ['小', '中', '大']
x = range(len(x_labels))
y = [-3, 0, 3]
# 在plt.xticks中，加入fontproperties=font30參數
plt.scatter(x, y)
plt.xticks(x,x_labels, fontproperties=font30)
plt.show()
