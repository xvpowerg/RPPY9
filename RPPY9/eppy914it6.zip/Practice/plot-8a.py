import matplotlib.pyplot as plt
import numpy as np
city = ['Delhi', 'Beijing', 'Washington', 'Tokyo', 'Moscow']
pos = np.arange(len(city))
Happiness_Index = [60, 40, 70, 65, 85]
#請加入語法
plt.show( )
