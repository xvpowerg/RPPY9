import matplotlib.pyplot as plt
data = [-1, -4.3, 15, 21, 31]
plt.figure(num=3, figsize=(8, 5),)
#請加入語法
