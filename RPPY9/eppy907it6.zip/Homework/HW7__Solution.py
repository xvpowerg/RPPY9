spells = ["apple", "banana", "papaya", "watermelon"]
shout_spells = map(lambda a: a +'!!!', spells)
shout_spells_list = list(shout_spells)
print(shout_spells_list)
