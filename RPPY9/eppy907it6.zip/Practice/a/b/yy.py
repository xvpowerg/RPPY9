def fig2():
	print('fig2 domain') 