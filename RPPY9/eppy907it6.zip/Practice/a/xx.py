def fig1():
	print("fig1 domain")