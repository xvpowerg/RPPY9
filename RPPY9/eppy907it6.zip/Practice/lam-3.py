try1 = [lambda x: x ** 2,
         lambda x: x ** 3,
         lambda x: x ** 4]
print(try1.__class__)
for f in try1:
     print(f.__class__)
     print(f(3))
print(try1[0](11))
