print("一般函數處理")
def f1(x):
   return x ** 2
def f2(x):
  return x ** 3
def f3(x):
  return x ** 4
try2 = [f1, f2, f3]
for ff in try2:
    print(ff.__class__)
    print(ff(3))
print(try2[0](3))
