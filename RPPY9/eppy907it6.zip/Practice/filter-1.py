a = [1, 2, 3, 4, 5, 6]
list7=filter(lambda x : x % 2 == 0, a)
print(list(list7))
dict8 = [{'name': 'python', 'points': 10}, {'name': 'java', 'points': 8}]
list8=filter(lambda x : x['name'] == 'python', dict8)
print(list(list8))
