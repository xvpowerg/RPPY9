import  random
a=random.randint(0,100)
print(a)
b=random.randrange(0, 101, 2)
print(b)
c=random.random( )
print(c)
d=random.choice('abcdefg&#%^*f')
print(d)
