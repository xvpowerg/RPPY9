def multiply2(x):
	return x * 2
a = map(multiply2, [1, 2, 3, 4])
list1=list(a)
print(list1)
a=map(lambda x : x*2, [1, 2, 3, 4])
list2=list(a)
print(list2)
b=[1, 2, 3, 4]
c=b*2
print(c)
