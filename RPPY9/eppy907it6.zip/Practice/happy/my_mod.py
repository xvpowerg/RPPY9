import time
def happy_python():
	print("Happy Python")
happy_python()
time.sleep(10)