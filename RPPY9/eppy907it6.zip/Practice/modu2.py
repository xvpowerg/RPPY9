import modu
import a.xx
import a.b.yy
ob1=modu.test1( )  #create object
modu.fun1( )

a.xx.fig1()

a.b.yy.fig2()
'''
因權限因素不能呼叫使用主程式
'''
