#匿名函數當作參數傳入
print("匿名函數當作參數傳入")
mz = (lambda a = 'Wolfgangus', b = ' Theophilus', c = ' Mozart': a + b + c)
print(mz('Wolfgang', ' Amadeus'))
