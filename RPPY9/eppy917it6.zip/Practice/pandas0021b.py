import pandas as pd
import  numpy as np
from io import  StringIO
csv_data='''
A,B,C,D
2,3,4,5
6,34,6
10,,11,8
'''
df=pd.read_csv(StringIO(csv_data))
print(df)
#請補充