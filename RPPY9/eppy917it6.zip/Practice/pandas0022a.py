import pandas as pd
import  numpy as np
from io import  StringIO
csv_data='''
A,B,C,D
2,3,5,5
5,5,5,5
5,5,5,5
13,23,5,5
'''
df=pd.read_csv(StringIO(csv_data))
print(df)
print("------0----")
